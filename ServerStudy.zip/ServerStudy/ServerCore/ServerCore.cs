﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ServerCore
{
    class Program
    {
        static Listener listener = new Listener();
        static void OnAcceptHandler(Socket clientSocket)
        {
            try
            {
                byte[] recBuff = new byte[1024];
                int recBuffSize = clientSocket.Receive(recBuff);

                string recData = Encoding.UTF8.GetString(recBuff, 0, recBuffSize);

                Console.WriteLine($"[Client Data] : {recData}");

                // 클라이언트에 정보 전송
                clientSocket.Send(Encoding.UTF8.GetBytes("Welcome Client, My name is Server"));
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                Console.WriteLine("Error");
            }
        }

        static void Main(string[] args)
        {
            string host = Dns.GetHostName(); // dns를 받아옴
            IPHostEntry hostEntry = Dns.GetHostEntry(host); // dns를 통해 ip를 받아옴
            IPAddress iPAddress = hostEntry.AddressList[0]; // ip리스트 중 첫번째 아이피를 받아옴
            IPEndPoint endPoint = new IPEndPoint(iPAddress, 7777); // 최종적으로 아이피와 포트번호를 저장
            
            listener.Init(endPoint, OnAcceptHandler);
            Console.WriteLine("Waiting...");
            while(true)
            {; }




        }
    }
}
